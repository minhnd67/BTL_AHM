<style>
    <?php 
        include APPROOT . '/views/template/css/productDetail.css'
    ?> 
</style>
<div class="item-container">
    <div class="item">
        <div class="item-img">
            <a href="<?php echo URLROOT; ?>/products/show/1">
                <img src="/img/nhan.jpg" alt="nhẫn nữ">
            </a>
            <a class="detail" href="<?php echo URLROOT; ?>/products/show/1">Chi tiết &rarr;</a>
        </div>
        <div class="item-name-and-price">
            <a href="#">Nhẫn nữ Kim cương DJR2865</a>
            <span>45,670,000đ</span>
        </div>
    </div>
</div>

