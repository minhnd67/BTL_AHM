<style>
    <?php
        include APPROOT . '/views/template/css/page.css'
    ?>
</style>
<div class="pagination">
    <div class="container">
        
    </div>
</div>