<style>
    <?php 
        include APPROOT . '/views/template/css/mainFooter.css';
    ?>
</style>
<div class="main-footer">
    <div class="main-footer-container">
        <a class="item-footer-1" href="#"><i class="fas fa-phone"></i>0345613201</a>
        <a class="item-footer-2" href="#"><img src="/img/logo-t.png" alt="logo ahm"></a>
        <a class="item-footer-3" href="#"><i class="fas fa-map-marker-alt"></i>Hệ thống phân phối</a>
    </div>
</div>

