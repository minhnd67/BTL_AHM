<?php 

    class cartView {

        public function showCart($cart) {        
            require_once(APPROOT . '/views/template/page/cart.php');          
        }

    }
?>