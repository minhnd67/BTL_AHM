<?php 

    class findProductView {

        public function nameP($name) {        
            require_once(APPROOT . '/views/template/html/header.php');          
        }

    }
?>