<?php 

    class proDetView {

        public function show($temp) {        
            require_once(APPROOT . '/views/template/page/showProductDetail.php');
        }

    }
?>