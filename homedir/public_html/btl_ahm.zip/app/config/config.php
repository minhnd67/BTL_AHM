<?php
    //Database params
    define('DB_HOST', 'localhost'); //Add your db host
    define('DB_USER', 'catsecur'); // Add your DB root
    define('DB_PASS', 'Abuabu22080303'); //Add your DB pass
    define('DB_NAME', 'catsecur_ahm2705'); //Add your DB Name

    //APPROOT
    define('APPROOT', dirname(dirname(__FILE__)));

    //URLROOT (Dynamic links)
    define('URLROOT', 'https://catsecure.vn');

    //Sitename
    define('SITENAME', 'Login & Register script');
